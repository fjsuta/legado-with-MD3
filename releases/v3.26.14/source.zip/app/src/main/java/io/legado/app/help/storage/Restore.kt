package io.legado.app.help.storage

import android.content.Context
import android.database.sqlite.SQLiteConstraintException
import android.net.Uri
import androidx.core.content.edit
import androidx.documentfile.provider.DocumentFile
import io.legado.app.BuildConfig
import io.legado.app.R
import io.legado.app.constant.AppConst.androidId
import io.legado.app.constant.AppLog
import io.legado.app.constant.PreferKey
import io.legado.app.data.appDb
import io.legado.app.data.entities.Book
import io.legado.app.data.entities.BookGroup
import io.legado.app.data.entities.BookSource
import io.legado.app.data.entities.Bookmark
import io.legado.app.data.entities.DictRule
import io.legado.app.data.entities.HttpTTS
import io.legado.app.data.entities.KeyboardAssist
import io.legado.app.data.entities.ReplaceRule
import io.legado.app.data.entities.RssSource
import io.legado.app.data.entities.RssStar
import io.legado.app.data.entities.RuleSub
import io.legado.app.data.entities.SearchKeyword
import io.legado.app.data.entities.Server
import io.legado.app.data.entities.TxtTocRule
import io.legado.app.data.entities.readRecord.ReadRecord
import io.legado.app.data.entities.readRecord.ReadRecordDetail
import io.legado.app.data.entities.readRecord.ReadRecordSession
import io.legado.app.data.repository.SettingsRepository
import io.legado.app.help.DirectLinkUpload
import io.legado.app.help.LauncherIconHelp
import io.legado.app.help.book.isLocal
import io.legado.app.help.book.upType
import io.legado.app.help.config.LocalConfig
import io.legado.app.help.config.OldThemeConfig
import io.legado.app.help.config.ReadBookConfig
import io.legado.app.model.BookCover
import io.legado.app.model.localBook.LocalBook
import io.legado.app.utils.ACache
import io.legado.app.utils.FileUtils
import io.legado.app.utils.GSON
import io.legado.app.utils.LogUtils
import io.legado.app.utils.compress.ZipUtils
import io.legado.app.utils.defaultSharedPreferences
import io.legado.app.utils.fromJsonArray
import io.legado.app.utils.getPrefBoolean
import io.legado.app.utils.getPrefInt
import io.legado.app.utils.getPrefString
import io.legado.app.utils.getSharedPreferences
import io.legado.app.utils.isContentScheme
import io.legado.app.utils.isJsonArray
import io.legado.app.utils.openInputStream
import io.legado.app.utils.toastOnUi
import kotlinx.coroutines.Dispatchers.Main
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import splitties.init.appCtx
import java.io.File
import java.io.FileInputStream

/**
 * 恢复
 */
object Restore : KoinComponent {

    private val settingsRepository: SettingsRepository by inject()
    private const val TAG = "Restore"

    suspend fun restore(context: Context, uri: Uri) {
        BackupRestoreLock.withLock {
            LogUtils.d(TAG, "开始恢复备份 uri:$uri")
            val unzipResult = kotlin.runCatching {
                FileUtils.delete(Backup.backupPath)
                if (uri.isContentScheme()) {
                    DocumentFile.fromSingleUri(context, uri)!!.openInputStream()!!.use {
                        ZipUtils.unZipToPath(it, Backup.backupPath)
                    }
                } else {
                    ZipUtils.unZipToPath(File(uri.path!!), Backup.backupPath)
                }
            }.onFailure {
                AppLog.put("复制解压文件出错\n${it.localizedMessage}", it)
            }
            if (unzipResult.isSuccess) {
                kotlin.runCatching {
                    restoreUnzipped(Backup.backupPath)
                    LocalConfig.lastBackup = System.currentTimeMillis()
                }.onFailure {
                    appCtx.toastOnUi("恢复备份出错\n${it.localizedMessage}")
                    AppLog.put("恢复备份出错\n${it.localizedMessage}", it)
                }
            }
        }
    }

    suspend fun restoreLocked(path: String) {
        BackupRestoreLock.withLock {
            restoreUnzipped(path)
        }
    }

    internal suspend fun restoreUnzipped(path: String) {
        restore(path)
    }

    private suspend fun restore(path: String) {
        val aes = BackupAES()
        fileToListT<Book>(path, "bookshelf.json")?.let {
            it.forEach { book ->
                book.upType()
            }
            it.filter { book -> book.isLocal }
                .forEach { book ->
                    book.coverUrl = LocalBook.getCoverPath(book)
                }
            val newBooks = arrayListOf<Book>()
            val ignoreLocalBook = BackupConfig.ignoreLocalBook
            it.forEach { book ->
                if (ignoreLocalBook && book.isLocal) {
                    return@forEach
                }
                if (appDb.bookDao.has(book.bookUrl)) {
                    try {
                        appDb.bookDao.update(book)
                    } catch (_: SQLiteConstraintException) {
                        appDb.bookDao.insert(book)
                    }
                } else {
                    newBooks.add(book)
                }
            }
            appDb.bookDao.insert(*newBooks.toTypedArray())
        }
        fileToListT<Bookmark>(path, "bookmark.json")?.let {
            try {
                appDb.bookmarkDao.insert(*it.toTypedArray())
            } catch (_: SQLiteConstraintException) {
            }
        }
        fileToListT<BookGroup>(path, "bookGroup.json")?.let {
            try {
                appDb.bookGroupDao.insert(*it.toTypedArray())
            } catch (_: SQLiteConstraintException) {
            }
        }
        fileToListT<BookSource>(path, "bookSource.json")?.let {
            try {
                appDb.bookSourceDao.insert(*it.toTypedArray())
            } catch (_: SQLiteConstraintException) {
            }
        } ?: run {
            val bookSourceFile = File(path, "bookSource.json")
            if (bookSourceFile.exists()) {
                val json = bookSourceFile.readText()
                ImportOldData.importOldSource(json)
            }
        }
        fileToListT<RssSource>(path, "rssSources.json")?.let {
            try {
                appDb.rssSourceDao.insert(*it.toTypedArray())
            } catch (_: SQLiteConstraintException) {
            }
        }
        fileToListT<RssStar>(path, "rssStar.json")?.let {
            try {
                appDb.rssStarDao.insert(*it.toTypedArray())
            } catch (_: SQLiteConstraintException) {
            }
        }
        fileToListT<ReplaceRule>(path, "replaceRule.json")?.let {
            try {
                appDb.replaceRuleDao.insert(*it.toTypedArray())
            } catch (_: SQLiteConstraintException) {
            }
        }
        fileToListT<SearchKeyword>(path, "searchHistory.json")?.let {
            try {
                appDb.searchKeywordDao.insert(*it.toTypedArray())
            } catch (_: SQLiteConstraintException) {
            }
        }
        fileToListT<RuleSub>(path, "sourceSub.json")?.let {
            try {
                appDb.ruleSubDao.insert(*it.toTypedArray())
            } catch (_: SQLiteConstraintException) {
            }
        }
        fileToListT<TxtTocRule>(path, "txtTocRule.json")?.let {
            try {
                appDb.txtTocRuleDao.insert(*it.toTypedArray())
            } catch (_: SQLiteConstraintException) {
            }
        }
        fileToListT<HttpTTS>(path, "httpTTS.json")?.let {
            try {
                appDb.httpTTSDao.insert(*it.toTypedArray())
            } catch (_: SQLiteConstraintException) {
            }
        }
        fileToListT<DictRule>(path, "dictRule.json")?.let {
            try {
                appDb.dictRuleDao.insert(*it.toTypedArray())
            } catch (_: SQLiteConstraintException) {
            }
        }
        fileToListT<KeyboardAssist>(path, "keyboardAssists.json")?.let {
            try {
                appDb.keyboardAssistsDao.insert(*it.toTypedArray())
            } catch (_: SQLiteConstraintException) {
            }
        }
        fileToListT<ReadRecord>(path, "readRecord.json")?.let {
            it.forEach { readRecord ->
                if (readRecord.deviceId != androidId) {
                    try {
                        appDb.readRecordDao.insert(readRecord)
                    } catch (_: SQLiteConstraintException) {
                    }
                } else {
                    val time = appDb.readRecordDao
                        .getReadTime(readRecord.deviceId, readRecord.bookName, readRecord.bookAuthor)
                    if (time == null || time < readRecord.readTime) {
                        try {
                            appDb.readRecordDao.insert(readRecord)
                        } catch (_: SQLiteConstraintException) {
                        }
                    }
                }
            }
        }
        fileToListT<ReadRecordDetail>(path, "readRecordDetail.json")?.let {
            it.forEach { detail ->
                try {
                    appDb.readRecordDao.insertDetail(detail)
                } catch (_: SQLiteConstraintException) {
                }
            }
        }
        fileToListT<ReadRecordSession>(path, "readRecordSession.json")?.let {
            it.forEach { session ->
                try {
                    appDb.readRecordDao.insertSession(session)
                } catch (_: SQLiteConstraintException) {
                }
            }
        }
        File(path, "servers.json").takeIf {
            it.exists()
        }?.runCatching {
            var json = readText()
            if (!json.isJsonArray()) {
                json = aes.decryptStr(json)
            }
            GSON.fromJsonArray<Server>(json).getOrNull()?.let {
                try {
                    appDb.serverDao.insert(*it.toTypedArray())
                } catch (_: SQLiteConstraintException) {
                }
            }
        }?.onFailure {
            AppLog.put("恢复服务器配置出错\n${it.localizedMessage}", it)
        }
        File(path, DirectLinkUpload.ruleFileName).takeIf {
            it.exists()
        }?.runCatching {
            val json = readText()
            ACache.get(cacheDir = false).put(DirectLinkUpload.ruleFileName, json)
        }?.onFailure {
            AppLog.put("恢复直链上传出错\n${it.localizedMessage}", it)
        }
        //恢复主题配置
        File(path, OldThemeConfig.configFileName).takeIf {
            it.exists()
        }?.runCatching {
            FileUtils.delete(OldThemeConfig.configFilePath)
            copyTo(File(OldThemeConfig.configFilePath))
            OldThemeConfig.upConfig()
        }?.onFailure {
            AppLog.put("恢复主题出错\n${it.localizedMessage}", it)
        }
        File(path, BookCover.configFileName).takeIf {
            it.exists()
        }?.runCatching {
            val json = readText()
            BookCover.saveCoverRule(json)
        }?.onFailure {
            AppLog.put("恢复封面规则出错\n${it.localizedMessage}", it)
        }
        if (!BackupConfig.ignoreReadConfig) {
            //恢复阅读界面配置
            File(path, ReadBookConfig.configFileName).takeIf {
                it.exists()
            }?.runCatching {
                FileUtils.delete(ReadBookConfig.configFilePath)
                copyTo(File(ReadBookConfig.configFilePath))
                ReadBookConfig.initConfigs()
            }?.onFailure {
                AppLog.put("恢复阅读界面出错\n${it.localizedMessage}", it)
            }
            File(path, ReadBookConfig.shareConfigFileName).takeIf {
                it.exists()
            }?.runCatching {
                FileUtils.delete(ReadBookConfig.shareConfigFilePath)
                copyTo(File(ReadBookConfig.shareConfigFilePath))
                ReadBookConfig.initShareConfig()
            }?.onFailure {
                AppLog.put("恢复阅读界面出错\n${it.localizedMessage}", it)
            }
        }
        //AppWebDav.downBgs()
        appCtx.getSharedPreferences(path, "config")?.all?.let { map ->
            val finalMap = mutableMapOf<String, Any>()
            appCtx.defaultSharedPreferences.edit {
                map.forEach { (key, value) ->
                    if (BackupConfig.keyIsNotIgnore(key)) {
                        when (key) {
                            PreferKey.webDavPassword -> {
                                val password = kotlin.runCatching {
                                    aes.decryptStr(value.toString())
                                }.getOrNull() ?: let {
                                    if (appCtx.getPrefString(PreferKey.webDavPassword).isNullOrBlank()) {
                                        value.toString()
                                    } else null
                                }
                                password?.let {
                                    putString(key, it)
                                    finalMap[key] = it
                                }
                            }

                            else -> {
                                when (value) {
                                    is Int -> { putInt(key, value); finalMap[key] = value }
                                    is Boolean -> { putBoolean(key, value); finalMap[key] = value }
                                    is Long -> { putLong(key, value); finalMap[key] = value }
                                    is Float -> { putFloat(key, value); finalMap[key] = value }
                                    is String -> { putString(key, value); finalMap[key] = value }
                                }
                            }
                        }
                    }
                }
            }
            // 同步恢复到 DataStore
            settingsRepository.batchPutFromMap(finalMap)
        }
        ReadBookConfig.apply {
            comicStyleSelect = appCtx.getPrefInt(PreferKey.comicStyleSelect)
            readStyleSelect = appCtx.getPrefInt(PreferKey.readStyleSelect)
            shareLayout = appCtx.getPrefBoolean(PreferKey.shareLayout)
            hideStatusBar = appCtx.getPrefBoolean(PreferKey.hideStatusBar)
            hideNavigationBar = appCtx.getPrefBoolean(PreferKey.hideNavigationBar)
            autoReadSpeed = appCtx.getPrefInt(PreferKey.autoReadSpeed, 46)
        }
        appCtx.toastOnUi(R.string.restore_success)
        withContext(Main) {
            delay(100)
            if (!BuildConfig.DEBUG) {
                LauncherIconHelp.changeIcon(appCtx.getPrefString(PreferKey.launcherIcon))
            }
            OldThemeConfig.applyDayNight(appCtx)
        }
    }

    private inline fun <reified T> fileToListT(path: String, fileName: String): List<T>? {
        try {
            val file = File(path, fileName)
            if (file.exists()) {
                LogUtils.d(TAG, "阅读恢复备份 $fileName 文件大小 ${file.length()}")
                FileInputStream(file).use {
                    return GSON.fromJsonArray<T>(it).getOrThrow().also { list ->
                        LogUtils.d(TAG, "阅读恢复备份 $fileName 列表大小 ${list.size}")
                    }
                }
            } else {
                LogUtils.d(TAG, "阅读恢复备份 $fileName 文件不存在")
            }
        } catch (e: Exception) {
            AppLog.put("$fileName\n读取解析出错\n${e.localizedMessage}", e)
            appCtx.toastOnUi("$fileName\n读取文件出错\n${e.localizedMessage}")
        }
        return null
    }

}
